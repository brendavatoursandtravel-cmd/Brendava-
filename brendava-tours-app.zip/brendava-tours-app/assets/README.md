# Assets

Replace these placeholders with your brand assets before publishing:

| File | Size | Purpose |
|------|------|---------|
| `icon.png` | 1024×1024 | App icon |
| `splash.png` | 1284×2778 (or similar) | Splash screen |
| `adaptive-icon.png` | 1024×1024 | Android adaptive icon foreground |
| `favicon.png` | 48×48 | Web favicon |

Brand colour: **#1a4d2e** (deep forest green)

You can generate icons quickly with https://www.appicon.co or Expo’s `npx expo-splash-screen`.
